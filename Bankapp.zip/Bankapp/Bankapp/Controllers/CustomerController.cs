﻿using Bankapp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Helpers;
using System.Web.Mvc;

namespace Bankapp.Controllers
{
    public class CustomerController : Controller
    {
        private readonly BankDBEntities db = new BankDBEntities();


        public ActionResult CustomerHome()
        {
            if (Session["Username"] == null || (string)Session["Role"] != "Customer")
            {
                return RedirectToAction("Login", "Bank");
            }

            string username = Session["Username"].ToString();
            var customer = db.Customers.FirstOrDefault(c => c.C_NAME == username);
            if (customer == null)
            {
                TempData["ErrorMessage"] = "Customer not found!";
                return RedirectToAction("Login", "Bank");
            }

            return View(customer);
        }
        // View Account
        public ActionResult ViewAccount()
        {
            var customerId = Session["CustomerId"] as int?;
            if (customerId == null)
            {
                TempData["ErrorMessage"] = "Session expired. Please log in again.";
                return RedirectToAction("Login", "Bank");
            }

            var customer = db.Customers.FirstOrDefault(c => c.C_ID == customerId.Value);
            if (customer == null)
            {
                TempData["ErrorMessage"] = "Customer not found!";
                return RedirectToAction("Login", "Bank");
            }

            var savingsAccount = db.Savings_Account.FirstOrDefault(a => a.SB_CUSTOMER_ID == customerId.Value);
            var fdAccounts = db.Fixed_Deposit_Account.Where(f => f.FD_CUSTOMER_ID == customerId.Value).ToList();
            var loanAccounts = db.Home_Loan_Account.Where(l => l.LN_CUSTOMER_ID == customerId.Value).ToList();

            if (savingsAccount == null && !fdAccounts.Any() && !loanAccounts.Any())
            {
                TempData["ErrorMessage"] = "No accounts found. Please contact your branch manager to open a Savings account.";
                return RedirectToAction("CustomerHome", "Customer");
            }

            var model = new CustomerAccountViewModel
            {
                Customer = customer,
                SavingsAccount = savingsAccount,
                FDAccounts = fdAccounts,
                LoanAccounts = loanAccounts
            };

            return View(model);
        }



        public ActionResult ViewBalance(int id)
        {
            var account = db.Savings_Account.FirstOrDefault(a => a.SB_CUSTOMER_ID == id);
            if (account == null)
            {
                TempData["ErrorMessage"] = "Account not found!";
                return RedirectToAction("CustomerHome", new { id });
            }
            ViewBag.Balance = account.SB_BALANCE;
            return View();
        }



        [HttpGet]
        public ActionResult Deposit()
        {
            if (Session["CustomerId"] == null)
            {
                TempData["ErrorMessage"] = "Session expired. Please log in again.";
                return RedirectToAction("Login", "Bank");
            }

            ViewBag.CustomerId = Session["CustomerId"];
            return View();
        }

        [HttpPost]
        public ActionResult Deposit(decimal amount)
        {
            if (Session["CustomerId"] == null)
            {
                TempData["ErrorMessage"] = "Session expired. Please log in again.";
                return RedirectToAction("Login", "Bank");
            }

            int customerId = Convert.ToInt32(Session["CustomerId"]);


            var account = db.Savings_Account.FirstOrDefault(a => a.SB_CUSTOMER_ID == customerId);
            if (account == null)
            {
                TempData["ErrorMessage"] = "Account not found!";
                return RedirectToAction("CustomerHome");
            }


            if (amount <= 0)
            {
                TempData["ErrorMessage"] = "Amount must be greater than 0!";
                return RedirectToAction("Deposit");
            }


            account.SB_BALANCE += amount;
            db.SaveChanges();
            var lastTransaction = db.Savings_Transaction
            .OrderByDescending(t => t.ST_TRANSACTION_ID)
            .FirstOrDefault();

            string newTransactionId = "TN001";
            if (lastTransaction != null && lastTransaction.ST_TRANSACTION_ID.Length > 2)
            {
                int lastNum = int.Parse(lastTransaction.ST_TRANSACTION_ID.Substring(2));
                newTransactionId = "TN" + (lastNum + 1).ToString("D3");
            }

            var transaction = new Savings_Transaction
            {
                ST_TRANSACTION_ID = newTransactionId,
                ST_ACCOUNT_ID = account.SB_ACCOUNT_ID,
                ST_TRANSACTION_TYPE = "Deposit",
                ST_AMOUNT = amount,
                ST_DEPOSIT = amount,
                ST_WITHDRAWL = null,
                ST_TRANSACTION_DATE = DateTime.Now
            };
            db.Savings_Transaction.Add(transaction);
            db.SaveChanges();

            TempData["SuccessMessage"] = $"₹{amount} deposited successfully!";
            return RedirectToAction("CustomerHome");
        }

        [HttpGet]
        public ActionResult Withdraw()
        {

            if (Session["CustomerId"] == null)
            {
                TempData["ErrorMessage"] = "Session expired. Please log in again.";
                return RedirectToAction("Login", "Bank");
            }


            ViewBag.CustomerId = Session["CustomerId"];
            return View();
        }


        [HttpPost]
        public ActionResult Withdraw(decimal amount)
        {

            if (Session["CustomerId"] == null)
            {
                TempData["ErrorMessage"] = "Session expired. Please log in again.";
                return RedirectToAction("Login", "Bank");
            }

            int customerId = Convert.ToInt32(Session["CustomerId"]);


            var account = db.Savings_Account.FirstOrDefault(a => a.SB_CUSTOMER_ID == customerId);
            if (account == null)
            {
                TempData["ErrorMessage"] = "Account not found!";
                return RedirectToAction("CustomerHome");
            }


            if (amount <= 0)
            {
                TempData["ErrorMessage"] = "Amount must be greater than 0!";
                return RedirectToAction("Withdraw");
            }

            if (amount > account.SB_BALANCE)
            {
                TempData["ErrorMessage"] = "Insufficient balance!";
                return RedirectToAction("Withdraw");
            }


            account.SB_BALANCE -= amount;
            db.SaveChanges();

            TempData["SuccessMessage"] = $"₹{amount} withdrawn successfully!";
            return RedirectToAction("CustomerHome");
        }
        [HttpGet]
        public ActionResult CreateFD()
        {
            if (Session["CustomerID"] == null)
                return RedirectToAction("Login", "Home");

            int customerId = Convert.ToInt32(Session["CustomerID"]);

            var existingFD = db.Fixed_Deposit_Account
                .FirstOrDefault(fd => fd.FD_CUSTOMER_ID == customerId && fd.FD_IS_CLOSED == false);

            if (existingFD != null)
            {
                TempData["ErrorMessage"] = "You already have an active FD account!";
                return RedirectToAction("ViewTransactions");
            }

            return View();
        }




        [HttpPost]
        public ActionResult CreateFD(decimal amount, int tenure)
        {
            var customerId = Convert.ToInt32(Session["CustomerID"]);
            var customer = db.Customers.FirstOrDefault(c => c.C_ID == customerId);

            if (customer == null)
            {
                TempData["ErrorMessage"] = "Session expired or customer not found.";
                return RedirectToAction("Login", "Home");
            }

            if (amount <= 0)
            {
                TempData["ErrorMessage"] = "Invalid amount.";
                return RedirectToAction("CreateFD");
            }


            var lastFD = db.Fixed_Deposit_Account.OrderByDescending(f => f.FD_ACCOUNT_ID).FirstOrDefault();
            string newFdId = "FD001";
            if (lastFD != null)
            {

                int lastNumber = int.Parse(new string(lastFD.FD_ACCOUNT_ID.Where(char.IsDigit).ToArray()));
                newFdId = "FD" + (lastNumber + 1).ToString("D3");
            }


            DateTime dob = customer.C_DOB ?? DateTime.MinValue;
            int age = (int)((DateTime.Now - dob).TotalDays / 365.25);
            bool isSeniorCitizen = age >= 60;

            decimal roi;
            if (isSeniorCitizen) roi = 9.5m;
            else if (tenure <= 1) roi = 6m;
            else if (tenure <= 2) roi = 7m;
            else roi = 8m;

            var startDate = DateTime.Now;
            var endDate = startDate.AddYears(tenure);


            var maturityAmount = amount * (decimal)Math.Pow((double)(1 + roi / 100), tenure);


            var fd = new Fixed_Deposit_Account
            {
                FD_ACCOUNT_ID = newFdId,
                FD_CUSTOMER_ID = customer.C_ID,
                FD_START_DATE = startDate,
                FD_END_DATE = endDate,
                FD_TENURE = tenure,
                FD_AMOUNT = amount,
                FD_ROI = roi,
                FD_IS_CLOSED = false
            };

            db.Fixed_Deposit_Account.Add(fd);
            db.SaveChanges();

            TempData["SuccessMessage"] = $"FD created successfully with ID {newFdId}. Maturity Amount: ₹{maturityAmount:F2}";
            return RedirectToAction("ViewTransactions");
        }




        public ActionResult ViewTransactions()
        {
            if (Session["CustomerID"] == null)
                return RedirectToAction("Login", "Home");

            int customerId = Convert.ToInt32(Session["CustomerID"]);

            var savings = (from s in db.Savings_Transaction
                           join a in db.Savings_Account on s.ST_ACCOUNT_ID equals a.SB_ACCOUNT_ID
                           where a.SB_CUSTOMER_ID == customerId
                           select s).ToList();

            var fds = db.Fixed_Deposit_Account
                        .Where(fd => fd.FD_CUSTOMER_ID == customerId)
                        .ToList();

            ViewBag.Savings = savings;
            ViewBag.FDs = fds;

            return View();
        }
    }
}

