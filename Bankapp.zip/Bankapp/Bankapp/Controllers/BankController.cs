﻿using Bankapp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using static System.Web.Razor.Parser.SyntaxConstants;
namespace Bankapp.Controllers
{
    public class BankController : Controller
    {
        // GET: Bank
        BankDBEntities db = new BankDBEntities();

        //[HttpGet]
        //public ActionResult Login()
        //{
        //    return View();
        //}

        //[HttpPost]
        //public ActionResult Login(string Username, string Pwd)
        //{
        //    var user = db.LoginPages.FirstOrDefault(x => x.USERNAME == Username && x.Pwd == Pwd);

        //    if (user != null)
        //    {
        //        Session["Username"] = user.USERNAME;
        //        Session["Userrole"] = user.Userrole;
        //        return RedirectToAction("Index", "Home");
        //    }
        //    else
        //    {
        //        ViewBag.ErrorMessage = "Invalid Username or Password";
        //        return View();
        //    }
        public ActionResult Login()
        {
            return View();
        }

        // POST: Login
        [HttpPost]
        public ActionResult Login(string Role, string Username, string Password)
        {
            if (string.IsNullOrEmpty(Role) || string.IsNullOrEmpty(Username) || string.IsNullOrEmpty(Password))
            {
                ViewBag.Message = "All fields are required!";
                return View();
            }

            var user = db.LoginPages.FirstOrDefault(u => u.USERNAME == Username && u.Pwd == Password && u.Userrole == Role);

            if (user == null)
            {
                ViewBag.Message = "Invalid username, password, or role!";
                return View();
            }

            // Set session variables
            Session["Username"] = user.USERNAME;
            Session["Role"] = user.Userrole;
            Session["UserID"] = user.USERNAME; // or store CustomerID/EmployeeID if needed

            // Redirect based on role
            switch (Role)
            {
                case "Customer":
                    var customer = db.Customers.FirstOrDefault(c => c.C_NAME == Username); // Or use c.C_USERNAME if you have that

                    if (customer != null)
                    {
                        // ✅ Set session variables that will be used by all customer pages
                        Session["CustomerId"] = customer.C_ID;         // This is crucial
                        Session["CustomerName"] = customer.C_NAME;

                        return RedirectToAction("CustomerHome", "Customer");
                    }
                    else
                    {
                        ViewBag.Message = "Customer not found!";
                        return View();
                    }
                case "Employee":
                    return RedirectToAction("EmployeeDashboard");
                case "Manager":
                    return RedirectToAction("ManagerHome");
                default:
                    ViewBag.Message = "Invalid role selected!";
                    return View();
            }
        }



//public ActionResult CustomerHome(int customer)
//        {
//            if (Session["Username"] == null || (string)Session["Role"] != "Customer")
//            {
//                return RedirectToAction("Login");
//            }

//            ViewBag.Username = Session["Username"];
//            return View(customer);
//        }
        // GET: Register
        public ActionResult Register()
        {
            return View();
        }

        // POST: Register
        [HttpPost]
        public ActionResult Register(Customer customer)
        {
            if (!ModelState.IsValid)
            {
                return View(customer);
            }

            
            var existingUser = db.LoginPages.FirstOrDefault(u => u.USERNAME == customer.C_NAME);
            if (existingUser != null)
            {
                ModelState.AddModelError("C_NAME", "Username already exists. Please choose another.");
                return View(customer);
            }

         
            db.Customers.Add(customer);
            db.SaveChanges();

           
            db.LoginPages.Add(new LoginPage
            {
                USERNAME = customer.C_NAME,
                Pwd = customer.C_PASSWORD,
                Userrole = "Customer"
            });
            db.SaveChanges();

            TempData["Message"] = "Registration successful! Please login.";
            return RedirectToAction("Login");
        }
        public ActionResult Logout()
        {
            Session.Clear();
            Session.Abandon(); // End the session
            return RedirectToAction("Login");
        }
        public ActionResult EmployeeDashboard()
        {
            if (Session["Username"] == null || (string)Session["Role"] != "Employee")
            {
                return RedirectToAction("Login");
            }
            ViewBag.Username = Session["Username"];
            return View();
        }
        public ActionResult ManagerHome()
        {
            if (Session["Username"] == null || (string)Session["Role"] != "Manager")
            {
                return RedirectToAction("Login");
            }
            ViewBag.Username = Session["Username"];
            return View();
        }
    }
}
